"use strict";

var globals = {
    debugF : true,
    debugT : true
};
