Please enjoy this dataset, distributed by Infochimps.

There's a host of information about this file in the attached .yaml
file -- it's machine-readable for many programs, and human-readable
enough for many humans. The most current information can of course be
found at infochimps.com.

Infochimps.com is built on user-submitted data. If you spend some time to
re-format this data for your own use, or add to it, or annotate it, chances are
other Infochimps will enjoy those changes as well (and build on them, for your
benefit).  We'll host and distribute any dataset available under free/open
terms, and will market any dataset at the price and terms you set.

And if you build something wonderful and want to share it, please let us know:
we have a gallery of user projects and we'd love to feature yours.

Cheers,
infochimps.com
help@infochimps.com