This code is from here: https://github.com/prajwalkman/angular-slider
I have not yet put the time in to figure out the submodule trick. 
Thanks for the code Prajwal!
