# SportsGraph Trade Visualization Tool
Ever wonder if the owners of various sports franchises are colluding to defeat some other owner?
Well I did, and I wanted to use Angular and D3 in a non-work project, and thus the 'SportsGraph Trade Visualization Tool' was born.
Still in very early stages, it is already fun to watch it work. Lots of dots flying around the screen. At the moment that is it ;)

## Try it out ?
The checkins on github do not include the many required JS libraries.
However I keep up to dat tar.gz versions of the project in the dist/ folder. If you download and untar one of the files, and copy the entire contents into your favorite web servers www folder, everything should work!

##Current Dev Tasks
* maximize screen space
* slow down transitions / add vertical slider to control speed / remove force(?)
  * vertical speed slider
* make city clusters bigger
* make teams more apparent - correct colors / logos ?
* fisheye magnification
